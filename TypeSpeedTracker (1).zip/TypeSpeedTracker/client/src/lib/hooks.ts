import { useQuery } from "@tanstack/react-query";
import { TypingTest } from "@shared/schema";

// Hook to get a demo user (or create one if not existing)
export function useDemoUser() {
  return useQuery({
    queryKey: ['/api/demo-user'],
    staleTime: Infinity,
  });
}

// Hook to get all tests for a user
export function useUserTests(userId?: number) {
  return useQuery<TypingTest[]>({
    queryKey: userId ? [`/api/users/${userId}/tests`] : [],
    enabled: !!userId,
    staleTime: 60000, // 1 minute
  });
}

// Hook to get recent tests for a user
export function useRecentTests(userId?: number, limit: number = 5) {
  return useQuery<TypingTest[]>({
    queryKey: userId ? [`/api/users/${userId}/tests/recent`, { limit }] : [],
    enabled: !!userId,
    staleTime: 60000, // 1 minute
  });
}

// Hook to get text samples by difficulty
// The API returns TextSample objects with numeric IDs
export function useTextSamples(difficulty: string) {
  return useQuery<{ id: number; title: string; text: string; difficulty: string }[]>({
    queryKey: [`/api/samples/${difficulty}`],
    staleTime: Infinity, // Text samples don't change often
  });
}
