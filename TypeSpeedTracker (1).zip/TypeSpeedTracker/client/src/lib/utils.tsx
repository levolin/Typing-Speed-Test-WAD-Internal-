import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date): string {
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  }).format(date);
}

export function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// Calculate words per minute based on characters typed and time elapsed
export function calculateWPM(
  charactersTyped: number,
  timeInSeconds: number
): number {
  // Standard formula: (characters / 5) / minutes
  const minutes = timeInSeconds / 60;
  if (minutes === 0) return 0;
  
  // 5 characters is considered as one word
  return charactersTyped / 5 / minutes;
}

// Calculate accuracy based on correct characters and total typed
export function calculateAccuracy(
  correctCharacters: number,
  totalCharacters: number
): number {
  if (totalCharacters === 0) return 100;
  return (correctCharacters / totalCharacters) * 100;
}

// Format difficulty level for display
export function formatDifficulty(difficulty: string): string {
  return difficulty.charAt(0).toUpperCase() + difficulty.slice(1);
}
