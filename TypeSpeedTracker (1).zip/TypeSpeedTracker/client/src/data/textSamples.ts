import { TestDifficultyType } from "@shared/schema";

export interface TextSample {
  id: string;
  title: string;
  text: string;
  difficulty: TestDifficultyType;
}

export const defaultTextSamples: TextSample[] = [
  {
    id: "beginner1",
    title: "The Quick Brown Fox",
    difficulty: "beginner",
    text: "The quick brown fox jumps over the lazy dog. This paragraph is designed to use every letter of the alphabet at least once. It's a great way to practice typing speed and accuracy for beginners."
  },
  {
    id: "beginner2",
    title: "Typing Practice",
    difficulty: "beginner",
    text: "Learning to type quickly and accurately is an essential skill in today's digital world. Regular practice can help improve your typing speed and reduce errors. Start with short sessions and gradually increase your practice time."
  },
  {
    id: "intermediate1",
    title: "Introduction to Computers",
    difficulty: "intermediate",
    text: "Computers have revolutionized the way we live and work. From performing complex calculations to facilitating global communication, these electronic devices have become an integral part of modern society. Understanding how to efficiently use computers is becoming increasingly important in nearly every profession."
  },
  {
    id: "intermediate2",
    title: "The Internet",
    difficulty: "intermediate",
    text: "The Internet is a global network of interconnected computers that communicate using standardized protocols. It has transformed how we access information, communicate with others, and conduct business. Despite its relatively recent mainstream adoption, it's difficult to imagine modern life without the Internet's ubiquitous presence."
  },
  {
    id: "advanced1",
    title: "Artificial Intelligence",
    difficulty: "advanced",
    text: "Artificial Intelligence represents the culmination of decades of research in computer science, psychology, and philosophy. Modern AI systems utilize sophisticated algorithms and vast quantities of data to recognize patterns, make predictions, and solve complex problems. The field continues to evolve rapidly, with applications ranging from natural language processing to autonomous vehicles and advanced medical diagnostics."
  },
  {
    id: "advanced2",
    title: "Quantum Computing",
    difficulty: "advanced",
    text: "Quantum computing leverages the principles of quantum mechanics to process information in fundamentally different ways than classical computers. While traditional computers use bits that exist in binary states (0 or 1), quantum computers utilize quantum bits or qubits that can exist in multiple states simultaneously through a phenomenon called superposition. This potentially allows quantum computers to solve certain complex problems exponentially faster than their classical counterparts."
  }
];
