import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useDemoUser, useUserTests } from "@/lib/hooks";
import TestHistory from "@/components/TestHistory";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { formatDate } from "@/lib/utils.tsx";

export default function Progress() {
  const { data: user } = useDemoUser();
  const { data: tests, isLoading } = useUserTests(user?.userId);
  const [activeTab, setActiveTab] = useState("speed");

  const formatChartData = () => {
    if (!tests) return [];
    
    return tests.slice(0, 10).reverse().map(test => ({
      name: formatDate(new Date(test.completedAt)),
      wpm: Math.round(test.wpm),
      accuracy: Math.round(test.accuracy),
      errorsPerMinute: Math.round((test.errors / (test.duration / 60)) * 10) / 10,
    }));
  };

  const chartData = formatChartData();

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold mb-2">My Progress</h2>
        <p className="text-gray-600">Track your typing performance over time</p>
      </div>

      <Card className="mb-8">
        <CardContent className="pt-6">
          <Tabs defaultValue="speed" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="speed">Speed</TabsTrigger>
              <TabsTrigger value="accuracy">Accuracy</TabsTrigger>
              <TabsTrigger value="combined">Combined</TabsTrigger>
            </TabsList>
            
            <TabsContent value="speed" className="h-64 w-full">
              {isLoading ? (
                <div className="flex justify-center items-center h-full">
                  <p>Loading chart data...</p>
                </div>
              ) : chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="wpm" stroke="#3b82f6" name="WPM" />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex justify-center items-center h-full">
                  <p>No data available yet. Complete some typing tests to see your progress.</p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="accuracy" className="h-64 w-full">
              {isLoading ? (
                <div className="flex justify-center items-center h-full">
                  <p>Loading chart data...</p>
                </div>
              ) : chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="accuracy" stroke="#10b981" name="Accuracy %" />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex justify-center items-center h-full">
                  <p>No data available yet. Complete some typing tests to see your progress.</p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="combined" className="h-64 w-full">
              {isLoading ? (
                <div className="flex justify-center items-center h-full">
                  <p>Loading chart data...</p>
                </div>
              ) : chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Legend />
                    <Line yAxisId="left" type="monotone" dataKey="wpm" stroke="#3b82f6" name="WPM" />
                    <Line yAxisId="right" type="monotone" dataKey="accuracy" stroke="#10b981" name="Accuracy %" />
                    <Line yAxisId="left" type="monotone" dataKey="errorsPerMinute" stroke="#ef4444" name="Errors/min" />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex justify-center items-center h-full">
                  <p>No data available yet. Complete some typing tests to see your progress.</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Test History */}
      <TestHistory tests={tests} isLoading={isLoading} />
    </div>
  );
}
