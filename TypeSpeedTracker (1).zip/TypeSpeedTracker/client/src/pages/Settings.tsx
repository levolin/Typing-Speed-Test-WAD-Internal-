import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useDemoUser } from "@/lib/hooks";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { data: user } = useDemoUser();
  const { toast } = useToast();
  const [settings, setSettings] = useState({
    theme: "system",
    fontFamily: "default",
    fontSize: 16,
    soundEffects: true,
    keyboardSounds: false,
    showTimer: true,
    showWPM: true,
  });

  const handleSettingChange = (key: string, value: any) => {
    setSettings((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const handleSave = () => {
    // In a real app, we would save these settings to a database
    // For demo purposes, we'll just show a success message
    toast({
      title: "Settings saved",
      description: "Your preferences have been saved successfully.",
    });
  };

  const handleResetProgress = () => {
    // In a real app, we would clear the user's progress
    toast({
      title: "Progress reset",
      description: "All your typing test history has been cleared.",
      variant: "destructive",
    });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold mb-2">Settings</h2>
        <p className="text-gray-600">Customize your typing experience</p>
      </div>

      <Tabs defaultValue="appearance" className="space-y-4">
        <TabsList>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="typing">Typing</TabsTrigger>
          <TabsTrigger value="account">Account</TabsTrigger>
        </TabsList>
        
        <TabsContent value="appearance">
          <Card>
            <CardHeader>
              <CardTitle>Appearance</CardTitle>
              <CardDescription>
                Customize how TypeSpeed looks and feels
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="theme">Theme</Label>
                <Select 
                  value={settings.theme} 
                  onValueChange={(value) => handleSettingChange("theme", value)}
                >
                  <SelectTrigger id="theme">
                    <SelectValue placeholder="Select a theme" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="dark">Dark</SelectItem>
                    <SelectItem value="system">System</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="font-family">Font Family</Label>
                <Select 
                  value={settings.fontFamily} 
                  onValueChange={(value) => handleSettingChange("fontFamily", value)}
                >
                  <SelectTrigger id="font-family">
                    <SelectValue placeholder="Select a font" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default">Default (Inter)</SelectItem>
                    <SelectItem value="mono">Monospace</SelectItem>
                    <SelectItem value="sans">Sans Serif</SelectItem>
                    <SelectItem value="serif">Serif</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label htmlFor="font-size">Font Size</Label>
                  <span className="text-sm text-gray-500">{settings.fontSize}px</span>
                </div>
                <Slider
                  id="font-size"
                  min={12}
                  max={24}
                  step={1}
                  value={[settings.fontSize]}
                  onValueChange={(value) => handleSettingChange("fontSize", value[0])}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSave}>Save Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="typing">
          <Card>
            <CardHeader>
              <CardTitle>Typing Experience</CardTitle>
              <CardDescription>
                Customize your typing test settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="sound-effects">Sound Effects</Label>
                  <p className="text-sm text-gray-500">Enable sounds for test completion and achievements</p>
                </div>
                <Switch
                  id="sound-effects"
                  checked={settings.soundEffects}
                  onCheckedChange={(checked) => handleSettingChange("soundEffects", checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="keyboard-sounds">Keyboard Sounds</Label>
                  <p className="text-sm text-gray-500">Play typing sounds when keys are pressed</p>
                </div>
                <Switch
                  id="keyboard-sounds"
                  checked={settings.keyboardSounds}
                  onCheckedChange={(checked) => handleSettingChange("keyboardSounds", checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="show-timer">Show Timer</Label>
                  <p className="text-sm text-gray-500">Display countdown timer during tests</p>
                </div>
                <Switch
                  id="show-timer"
                  checked={settings.showTimer}
                  onCheckedChange={(checked) => handleSettingChange("showTimer", checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="show-wpm">Show WPM</Label>
                  <p className="text-sm text-gray-500">Display real-time WPM during tests</p>
                </div>
                <Switch
                  id="show-wpm"
                  checked={settings.showWPM}
                  onCheckedChange={(checked) => handleSettingChange("showWPM", checked)}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSave}>Save Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="account">
          <Card>
            <CardHeader>
              <CardTitle>Account Settings</CardTitle>
              <CardDescription>
                Manage your account and progress data
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-1">
                <h4 className="font-medium">User Information</h4>
                <p className="text-sm text-gray-500">Username: {user?.username || 'Demo User'}</p>
                <p className="text-sm text-gray-500">Account Type: Demo</p>
              </div>
              
              <div className="border-t pt-4">
                <h4 className="font-medium text-red-600 mb-2">Danger Zone</h4>
                <p className="text-sm text-gray-500 mb-4">These actions cannot be undone.</p>
                
                <Button 
                  variant="destructive" 
                  onClick={handleResetProgress}
                >
                  Reset All Progress
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
