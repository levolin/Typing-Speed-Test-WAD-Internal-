import { useState } from "react";
import TypingTest from "@/components/TypingTest";
import TestResults from "@/components/TestResults";
import ProgressCharts from "@/components/ProgressCharts";
import { useDemoUser, useRecentTests } from "@/lib/hooks";

export default function PracticeTest() {
  const { data: user } = useDemoUser();
  const { data: recentTests, isLoading } = useRecentTests(user?.userId);

  const [activeTest, setActiveTest] = useState<{
    id: number | null;
    wpm: number;
    accuracy: number;
    duration: number;
    keystrokes: number;
    errors: number;
  } | null>(null);

  const handleTestComplete = (result: {
    id: number;
    wpm: number;
    accuracy: number;
    duration: number;
    keystrokes: number;
    errors: number;
  }) => {
    setActiveTest(result);
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header Section */}
      <div className="mb-6">
        <h2 className="text-2xl font-semibold mb-2">Typing Test</h2>
        <p className="text-gray-600">Improve your typing speed and accuracy</p>
      </div>

      {/* Typing Test Component */}
      <TypingTest onTestComplete={handleTestComplete} userId={user?.userId} />

      {/* Test Results Component */}
      {activeTest && (
        <TestResults
          wpm={activeTest.wpm}
          accuracy={activeTest.accuracy}
          duration={activeTest.duration}
          keystrokes={activeTest.keystrokes}
          errors={activeTest.errors}
        />
      )}

      {/* Progress Charts Component */}
      {user && <ProgressCharts userId={user.userId} recentTests={recentTests} />}
    </div>
  );
}
