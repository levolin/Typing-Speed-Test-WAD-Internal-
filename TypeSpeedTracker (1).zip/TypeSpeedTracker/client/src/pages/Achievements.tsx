import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useDemoUser, useUserTests } from "@/lib/hooks";

export default function Achievements() {
  const { data: user } = useDemoUser();
  const { data: tests } = useUserTests(user?.userId);

  // Calculate stats from test history
  const stats = {
    testsCompleted: tests?.length || 0,
    avgWpm: tests && tests.length > 0 
      ? Math.round(tests.reduce((sum, test) => sum + test.wpm, 0) / tests.length) 
      : 0,
    maxWpm: tests && tests.length > 0
      ? Math.max(...tests.map(test => test.wpm))
      : 0,
    avgAccuracy: tests && tests.length > 0
      ? Math.round(tests.reduce((sum, test) => sum + test.accuracy, 0) / tests.length)
      : 0,
  };

  // Define achievements and their criteria
  const achievements = [
    {
      title: "First Steps",
      description: "Complete your first typing test",
      icon: "ri-footprint-line",
      progress: Math.min(stats.testsCompleted, 1) * 100,
      achieved: stats.testsCompleted >= 1,
      color: "bg-green-100 text-green-700"
    },
    {
      title: "Getting Warmed Up",
      description: "Complete 5 typing tests",
      icon: "ri-fire-line",
      progress: Math.min(stats.testsCompleted / 5, 1) * 100,
      achieved: stats.testsCompleted >= 5,
      color: "bg-orange-100 text-orange-700"
    },
    {
      title: "Speed Demon",
      description: "Reach 50 WPM in any test",
      icon: "ri-rocket-line",
      progress: Math.min(stats.maxWpm / 50, 1) * 100,
      achieved: stats.maxWpm >= 50,
      color: "bg-blue-100 text-blue-700"
    },
    {
      title: "Lightning Fingers",
      description: "Reach 80 WPM in any test",
      icon: "ri-flashlight-line",
      progress: Math.min(stats.maxWpm / 80, 1) * 100,
      achieved: stats.maxWpm >= 80,
      color: "bg-purple-100 text-purple-700"
    },
    {
      title: "Accuracy Master",
      description: "Achieve 95% accuracy or higher",
      icon: "ri-focus-3-line",
      progress: Math.min(stats.avgAccuracy / 95, 1) * 100,
      achieved: stats.avgAccuracy >= 95,
      color: "bg-yellow-100 text-yellow-700"
    },
    {
      title: "Dedication",
      description: "Complete 10 typing tests",
      icon: "ri-calendar-check-line",
      progress: Math.min(stats.testsCompleted / 10, 1) * 100,
      achieved: stats.testsCompleted >= 10,
      color: "bg-red-100 text-red-700"
    }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold mb-2">Achievements</h2>
        <p className="text-gray-600">Track your progress and earn achievements</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Tests Completed</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{stats.testsCompleted}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Average Speed</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{stats.avgWpm} <span className="text-sm font-normal text-gray-500">WPM</span></p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Max Speed</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{stats.maxWpm} <span className="text-sm font-normal text-gray-500">WPM</span></p>
          </CardContent>
        </Card>
      </div>

      <h3 className="text-xl font-semibold mb-4">Your Achievements</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {achievements.map((achievement, index) => (
          <Card key={index} className={`${achievement.achieved ? 'border-green-200 bg-green-50/30' : ''}`}>
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <div className={`p-2 rounded-full ${achievement.color}`}>
                  <i className={`${achievement.icon} text-xl`}></i>
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="font-medium">{achievement.title}</h4>
                    {achievement.achieved && (
                      <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                        Achieved
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{achievement.description}</p>
                  <Progress value={achievement.progress} className="h-2" />
                  <p className="text-xs text-gray-500 mt-1">{Math.round(achievement.progress)}% complete</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
