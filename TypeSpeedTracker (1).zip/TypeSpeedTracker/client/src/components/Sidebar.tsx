import { useLocation, Link } from "wouter";
import { useDemoUser } from "@/lib/hooks";

interface SidebarProps {
  isMobile?: boolean;
  onNavItemClick?: () => void;
}

export default function Sidebar({ isMobile = false, onNavItemClick }: SidebarProps) {
  const [location] = useLocation();
  const { data: user } = useDemoUser();

  const navItems = [
    { path: "/practice", icon: "ri-speed-up-line", label: "Practice Test" },
    { path: "/progress", icon: "ri-bar-chart-line", label: "My Progress" },
    { path: "/achievements", icon: "ri-trophy-line", label: "Achievements" },
    { path: "/settings", icon: "ri-settings-3-line", label: "Settings" },
  ];

  const isActive = (path: string) => {
    if (path === "/practice" && location === "/") return true;
    return location === path;
  };

  return (
    <aside className={`flex flex-col ${isMobile ? "" : "hidden md:flex w-64 bg-white border-r border-gray-200 p-4 h-screen"}`}>
      {!isMobile && (
        <div className="flex items-center gap-2 mb-8">
          <i className="ri-keyboard-box-fill text-2xl text-primary"></i>
          <h1 className="text-xl font-semibold">TypeSpeed</h1>
        </div>
      )}
      
      <nav className="flex flex-col space-y-1">
        {navItems.map((item) => (
          <Link 
            key={item.path}
            href={item.path}
            onClick={onNavItemClick}
          >
            <a 
              className={`flex items-center gap-3 px-4 py-3 rounded-lg ${
                isActive(item.path)
                  ? "bg-blue-50 text-primary"
                  : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <i className={item.icon}></i>
              <span>{item.label}</span>
            </a>
          </Link>
        ))}
      </nav>
      
      {user && (
        <div className="mt-auto">
          <div className="border-t border-gray-200 pt-4 mt-4">
            <div className="flex items-center gap-3 px-4 py-2">
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white">
                <span>{user.username.substring(0, 2).toUpperCase()}</span>
              </div>
              <div>
                <p className="text-sm font-medium">{user.username}</p>
                <p className="text-xs text-gray-500">Demo User</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}
