import { TypingTest } from "@shared/schema";
import { formatDate, formatTime } from "@/lib/utils.tsx";
import { Skeleton } from "@/components/ui/skeleton";

interface TestHistoryProps {
  tests?: TypingTest[];
  isLoading: boolean;
  limit?: number;
}

export default function TestHistory({ tests, isLoading, limit }: TestHistoryProps) {
  const limitedTests = limit && tests ? tests.slice(0, limit) : tests;

  if (isLoading) {
    return (
      <div className="space-y-4">
        <h4 className="font-medium text-base mb-3">Recent Tests</h4>
        {Array(3).fill(0).map((_, index) => (
          <div key={index} className="border-b border-gray-100 py-3">
            <div className="flex justify-between">
              <div>
                <Skeleton className="h-4 w-32 mb-2" />
                <Skeleton className="h-3 w-24" />
              </div>
              <div className="flex gap-4">
                <div>
                  <Skeleton className="h-3 w-16 mb-1" />
                  <Skeleton className="h-4 w-12" />
                </div>
                <div>
                  <Skeleton className="h-3 w-16 mb-1" />
                  <Skeleton className="h-4 w-12" />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!tests || tests.length === 0) {
    return (
      <div>
        <h4 className="font-medium text-base mb-3">Recent Tests</h4>
        <p className="text-gray-500 py-4 text-center">No test history yet. Complete a typing test to see your results.</p>
      </div>
    );
  }

  return (
    <div>
      <h4 className="font-medium text-base mb-3">Recent Tests</h4>
      
      {limitedTests?.map((test, index) => (
        <div key={test.id} className={`${index < (limitedTests.length - 1) ? 'border-b border-gray-100' : ''} py-3 flex items-center justify-between`}>
          <div>
            <p className="font-medium">{test.difficulty.charAt(0).toUpperCase() + test.difficulty.slice(1)} Test</p>
            <p className="text-sm text-gray-500">{formatDate(new Date(test.completedAt))} - {formatTime(test.duration)}</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm text-gray-500">Speed</p>
              <p className="font-medium">{Math.round(test.wpm)} WPM</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-500">Accuracy</p>
              <p className="font-medium">{Math.round(test.accuracy)}%</p>
            </div>
          </div>
        </div>
      ))}

      {limitedTests && limitedTests.length < (tests?.length || 0) && (
        <div className="flex justify-end mt-4">
          <a href="/progress" className="text-primary hover:text-primary/80 text-sm font-medium flex items-center gap-1">
            <span>View all test results</span>
            <i className="ri-arrow-right-line"></i>
          </a>
        </div>
      )}
    </div>
  );
}
