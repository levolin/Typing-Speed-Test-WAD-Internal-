import { ReactNode, useState } from "react";
import Sidebar from "./Sidebar";
import MobileNav from "./MobileNav";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      {/* Sidebar for desktop */}
      <Sidebar />

      {/* Main Content Area */}
      <main className="flex-1 overflow-auto">
        {/* Top Navigation Bar (Mobile) */}
        <div className="md:hidden bg-white border-b border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <i className="ri-keyboard-box-fill text-2xl text-primary"></i>
              <h1 className="text-xl font-semibold">TypeSpeed</h1>
            </div>
            <button 
              type="button" 
              className="text-gray-700"
              onClick={() => setMobileNavOpen(!mobileNavOpen)}
            >
              <i className="ri-menu-line text-2xl"></i>
            </button>
          </div>
        </div>

        {/* Mobile navigation drawer */}
        {mobileNavOpen && (
          <div className="md:hidden fixed inset-0 bg-black bg-opacity-50 z-40" onClick={() => setMobileNavOpen(false)}>
            <div className="absolute top-0 right-0 w-64 h-full bg-white" onClick={e => e.stopPropagation()}>
              <div className="p-4">
                <button 
                  className="absolute top-4 right-4 text-gray-500"
                  onClick={() => setMobileNavOpen(false)}
                >
                  <i className="ri-close-line text-2xl"></i>
                </button>
                <Sidebar isMobile onNavItemClick={() => setMobileNavOpen(false)} />
              </div>
            </div>
          </div>
        )}

        {/* Content Area */}
        <div className="p-4 md:p-8 pb-20 md:pb-8">
          {children}
        </div>
      </main>

      {/* Mobile Navigation Bar */}
      <MobileNav />
    </div>
  );
}
