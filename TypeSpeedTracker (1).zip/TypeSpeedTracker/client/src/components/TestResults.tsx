import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface TestResultsProps {
  wpm: number;
  accuracy: number;
  duration: number;
  keystrokes: number;
  errors: number;
}

export default function TestResults({ 
  wpm, 
  accuracy, 
  duration, 
  keystrokes, 
  errors 
}: TestResultsProps) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Calculate consistency based on error rate
  const errorRate = keystrokes > 0 ? (errors / keystrokes) * 100 : 0;
  const consistency = Math.max(0, 100 - errorRate * 5); // Formula to calculate consistency

  return (
    <Card className="mb-8">
      <CardContent className="pt-6">
        <h3 className="text-lg font-medium mb-4">Your Latest Results</h3>
        
        {/* Results Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-blue-50 rounded-lg p-4 border border-blue-100">
            <div className="flex items-center gap-3">
              <div className="bg-blue-100 p-2 rounded-full">
                <i className="ri-speed-up-line text-primary text-xl"></i>
              </div>
              <div>
                <p className="text-sm text-gray-500">Typing Speed</p>
                <p className="text-2xl font-semibold">{Math.round(wpm)} WPM</p>
              </div>
            </div>
          </div>
          
          <div className="bg-green-50 rounded-lg p-4 border border-green-100">
            <div className="flex items-center gap-3">
              <div className="bg-green-100 p-2 rounded-full">
                <i className="ri-checkbox-circle-line text-secondary text-xl"></i>
              </div>
              <div>
                <p className="text-sm text-gray-500">Accuracy</p>
                <p className="text-2xl font-semibold">{Math.round(accuracy)}%</p>
              </div>
            </div>
          </div>
          
          <div className="bg-violet-50 rounded-lg p-4 border border-violet-100">
            <div className="flex items-center gap-3">
              <div className="bg-violet-100 p-2 rounded-full">
                <i className="ri-time-line text-accent text-xl"></i>
              </div>
              <div>
                <p className="text-sm text-gray-500">Test Duration</p>
                <p className="text-2xl font-semibold">{formatTime(duration)}</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Detailed Metrics */}
        <div className="space-y-4 mb-6">
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-sm text-gray-600">Keystrokes</span>
              <span className="text-sm font-medium">{keystrokes}</span>
            </div>
            <div className="w-full bg-gray-200 h-2 rounded-full">
              <div 
                className="bg-primary h-2 rounded-full" 
                style={{ width: `${Math.min(100, (keystrokes / 300) * 100)}%` }}
              ></div>
            </div>
          </div>
          
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-sm text-gray-600">Errors</span>
              <span className="text-sm font-medium">{errors}</span>
            </div>
            <div className="w-full bg-gray-200 h-2 rounded-full">
              <div 
                className="bg-red-500 h-2 rounded-full" 
                style={{ width: `${Math.min(100, (errors / 20) * 100)}%` }}
              ></div>
            </div>
          </div>
          
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-sm text-gray-600">Consistency</span>
              <span className="text-sm font-medium">{Math.round(consistency)}%</span>
            </div>
            <div className="w-full bg-gray-200 h-2 rounded-full">
              <div 
                className="bg-amber-500 h-2 rounded-full" 
                style={{ width: `${consistency}%` }}
              ></div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
