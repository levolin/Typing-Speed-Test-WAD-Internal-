import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TypingTest } from "@shared/schema";
import { useUserTests } from "@/lib/hooks";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import TestHistory from "./TestHistory";
import { formatDate } from "@/lib/utils.tsx";

interface ProgressChartsProps {
  userId?: number;
  recentTests?: TypingTest[];
}

export default function ProgressCharts({ userId, recentTests }: ProgressChartsProps) {
  const [activeTab, setActiveTab] = useState("speed");
  const { data: allTests, isLoading } = useUserTests(userId);

  const formatChartData = () => {
    if (!allTests || allTests.length === 0) return [];
    
    return allTests.slice(0, 10).reverse().map(test => ({
      name: formatDate(new Date(test.completedAt)),
      wpm: Math.round(test.wpm),
      accuracy: Math.round(test.accuracy),
      errors: test.errors,
    }));
  };

  const chartData = formatChartData();

  return (
    <Card>
      <CardContent className="pt-6">
        <h3 className="text-lg font-medium mb-4">Your Progress</h3>
        
        {/* Chart Tabs */}
        <Tabs defaultValue="speed" value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList>
            <TabsTrigger value="speed">Speed</TabsTrigger>
            <TabsTrigger value="accuracy">Accuracy</TabsTrigger>
            <TabsTrigger value="combined">Combined</TabsTrigger>
          </TabsList>
          
          <TabsContent value="speed" className="h-64 mt-4">
            {isLoading ? (
              <div className="flex justify-center items-center h-full">
                <p>Loading chart data...</p>
              </div>
            ) : chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="wpm" stroke="#3b82f6" name="WPM" />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex justify-center items-center h-full">
                <p className="text-gray-500">Complete some typing tests to see your progress</p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="accuracy" className="h-64 mt-4">
            {isLoading ? (
              <div className="flex justify-center items-center h-full">
                <p>Loading chart data...</p>
              </div>
            ) : chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="accuracy" stroke="#10b981" name="Accuracy %" />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex justify-center items-center h-full">
                <p className="text-gray-500">Complete some typing tests to see your progress</p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="combined" className="h-64 mt-4">
            {isLoading ? (
              <div className="flex justify-center items-center h-full">
                <p>Loading chart data...</p>
              </div>
            ) : chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" domain={[0, 100]} />
                  <Tooltip />
                  <Legend />
                  <Line yAxisId="left" type="monotone" dataKey="wpm" stroke="#3b82f6" name="WPM" />
                  <Line yAxisId="right" type="monotone" dataKey="accuracy" stroke="#10b981" name="Accuracy %" />
                  <Line yAxisId="left" type="monotone" dataKey="errors" stroke="#ef4444" name="Errors" />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex justify-center items-center h-full">
                <p className="text-gray-500">Complete some typing tests to see your progress</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
        
        {/* Recent Tests */}
        {recentTests && <TestHistory tests={recentTests} isLoading={isLoading} limit={3} />}
      </CardContent>
    </Card>
  );
}
