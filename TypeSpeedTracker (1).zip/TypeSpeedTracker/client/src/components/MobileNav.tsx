import { useLocation, Link } from "wouter";

export default function MobileNav() {
  const [location] = useLocation();

  const navItems = [
    { path: "/practice", icon: "ri-speed-up-line", label: "Practice" },
    { path: "/progress", icon: "ri-bar-chart-line", label: "Progress" },
    { path: "/achievements", icon: "ri-trophy-line", label: "Achievements" },
    { path: "/settings", icon: "ri-user-line", label: "Profile" },
  ];

  const isActive = (path: string) => {
    if (path === "/practice" && location === "/") return true;
    return location === path;
  };

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around py-2">
      {navItems.map((item) => (
        <Link key={item.path} href={item.path}>
          <a className={`flex flex-col items-center p-2 ${
            isActive(item.path) ? "text-primary" : "text-gray-500"
          }`}>
            <i className={`${item.icon} text-xl`}></i>
            <span className="text-xs mt-1">{item.label}</span>
          </a>
        </Link>
      ))}
    </div>
  );
}
