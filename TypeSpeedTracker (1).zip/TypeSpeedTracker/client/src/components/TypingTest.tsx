import { useState, useEffect, useRef, useCallback } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { TestDifficultyType } from "@shared/schema";
import { useTextSamples } from "@/lib/hooks";

interface TypingTestProps {
  onTestComplete: (result: {
    id: number;
    wpm: number;
    accuracy: number;
    duration: number;
    keystrokes: number;
    errors: number;
  }) => void;
  userId?: number;
}

export default function TypingTest({ onTestComplete, userId }: TypingTestProps) {
  const [difficulty, setDifficulty] = useState<TestDifficultyType>("beginner");
  const { data: textSamples, isLoading } = useTextSamples(difficulty);
  
  const [selectedText, setSelectedText] = useState<{ id: number; text: string; title: string; difficulty: string } | null>(null);
  const [typedText, setTypedText] = useState("");
  const [status, setStatus] = useState<"idle" | "countdown" | "running" | "finished">("idle");
  const [startTime, setStartTime] = useState<number | null>(null);
  const [endTime, setEndTime] = useState<number | null>(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [wpm, setWpm] = useState(0);
  const [accuracy, setAccuracy] = useState(100);
  const [progress, setProgress] = useState(0);
  const [countdown, setCountdown] = useState(3);
  const [keystrokes, setKeystrokes] = useState(0);
  const [errors, setErrors] = useState(0);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const timerRef = useRef<number | null>(null);

  // Mutation to save test results
  const saveMutation = useMutation({
    mutationFn: (testData: any) => 
      apiRequest("POST", "/api/tests", testData),
    onSuccess: async (response) => {
      const result = await response.json();
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/tests`] });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/tests/recent`] });
      onTestComplete({
        id: result.id,
        wpm,
        accuracy,
        duration: elapsedTime,
        keystrokes,
        errors,
      });
      toast({
        title: "Test completed!",
        description: `Your typing speed was ${Math.round(wpm)} WPM with ${Math.round(accuracy)}% accuracy.`,
      });
    },
    onError: (error) => {
      console.error("Mutation error:", error);
      toast({
        title: "Error saving results",
        description: "There was a problem saving your test results.",
        variant: "destructive",
      });
    }
  });

  const startTest = useCallback(() => {
    if (!selectedText || !textSamples || textSamples.length === 0) {
      // Select a random text sample if none is selected
      if (textSamples && textSamples.length > 0) {
        const randomIndex = Math.floor(Math.random() * textSamples.length);
        setSelectedText(textSamples[randomIndex]);
      } else {
        toast({
          title: "No text samples available",
          description: "Please try again later or select a different difficulty level.",
          variant: "destructive",
        });
        return;
      }
    }

    setTypedText("");
    setStatus("countdown");
    setCountdown(3);
    
    // Focus the textarea
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  }, [selectedText, textSamples, toast]);

  // Handle difficulty change
  const handleDifficultyChange = (newDifficulty: TestDifficultyType) => {
    if (status === "idle" || status === "finished") {
      setDifficulty(newDifficulty);
      setSelectedText(null);
      resetTest();
    }
  };

  // Reset the test
  const resetTest = () => {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    
    setStatus("idle");
    setTypedText("");
    setStartTime(null);
    setEndTime(null);
    setElapsedTime(0);
    setWpm(0);
    setAccuracy(100);
    setProgress(0);
    setKeystrokes(0);
    setErrors(0);
  };

  // Start the countdown timer
  useEffect(() => {
    if (status === "countdown" && countdown > 0) {
      const timer = window.setTimeout(() => {
        setCountdown(countdown - 1);
      }, 1000);
      
      return () => window.clearTimeout(timer);
    } else if (status === "countdown" && countdown === 0) {
      setStatus("running");
      setStartTime(Date.now());
      setWpm(0);
      setAccuracy(100);
      setProgress(0);
      setKeystrokes(0);
      setErrors(0);
      
      // Start the timer
      timerRef.current = window.setInterval(() => {
        setElapsedTime(prev => prev + 1);
      }, 1000);
    }
  }, [status, countdown]);

  // Calculate WPM, accuracy, and progress during the test
  useEffect(() => {
    if (status === "running" && selectedText) {
      // Calculate WPM: (characters typed / 5) / minutes elapsed
      const minutes = elapsedTime / 60;
      const words = typedText.length / 5; // Standard: 5 characters = 1 word
      const currentWpm = minutes > 0 ? words / minutes : 0;
      
      // Calculate accuracy
      let correctChars = 0;
      let errorCount = 0;
      
      for (let i = 0; i < typedText.length; i++) {
        if (i >= selectedText.text.length || typedText[i] !== selectedText.text[i]) {
          errorCount++;
        } else {
          correctChars++;
        }
      }
      
      const currentAccuracy = typedText.length > 0 
        ? (correctChars / typedText.length) * 100 
        : 100;
      
      // Calculate progress
      const currentProgress = selectedText.text.length > 0
        ? (correctChars / selectedText.text.length) * 100
        : 0;
      
      setWpm(currentWpm);
      setAccuracy(currentAccuracy);
      setProgress(currentProgress);
      setErrors(errorCount);
      setKeystrokes(typedText.length);
      
      // Check if test is completed
      if (typedText.length >= selectedText.text.length) {
        finishTest();
      }
    }
  }, [typedText, elapsedTime, status, selectedText]);

  // Handle typing in the textarea
  const handleTyping = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (status === "running") {
      setTypedText(e.target.value);
    }
  };

  // Finish the test
  const finishTest = () => {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    
    setEndTime(Date.now());
    setStatus("finished");
    
    // Save results if userId is available
    if (userId && selectedText) {
      // Convert numeric ID to string for API
      const textSampleId = String(selectedText.id);
      
      const testData = {
        userId,
        difficulty,
        wpm,
        accuracy,
        keystrokes,
        errors,
        duration: elapsedTime,
        textSampleId,
      };
      
      console.log("Submitting test data:", testData);
      saveMutation.mutate(testData);
    } else {
      onTestComplete({
        id: 0,
        wpm,
        accuracy,
        duration: elapsedTime,
        keystrokes,
        errors,
      });
    }
  };

  // Select a random text when difficulty changes or samples load
  useEffect(() => {
    if (textSamples && textSamples.length > 0 && !selectedText && status === "idle") {
      const randomIndex = Math.floor(Math.random() * textSamples.length);
      setSelectedText(textSamples[randomIndex]);
    }
  }, [textSamples, selectedText, status]);

  // Clean up interval on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        window.clearInterval(timerRef.current);
      }
    };
  }, []);

  // Format time display (MM:SS)
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Render different parts of the text with highlighting
  const renderTextWithHighlighting = () => {
    if (!selectedText) return null;
    
    const text = selectedText.text;
    const typedLength = typedText.length;
    const elements = [];
    
    for (let i = 0; i < text.length; i++) {
      let className = "text-gray-400"; // Untyped text
      
      if (i < typedLength) {
        if (text[i] === typedText[i]) {
          className = "bg-secondary/20 text-gray-800"; // Correct
        } else {
          className = "bg-red-100 text-red-500"; // Incorrect
        }
      }
      
      elements.push(
        <span key={i} className={className}>
          {text[i]}
        </span>
      );
    }
    
    return elements;
  };

  return (
    <div className="mb-6">
      {/* Difficulty Selection */}
      <Card className="mb-6">
        <CardContent className="py-4">
          <h3 className="text-lg font-medium mb-3">Select Difficulty</h3>
          <div className="flex flex-wrap gap-3">
            <Button
              variant={difficulty === "beginner" ? "default" : "outline"}
              onClick={() => handleDifficultyChange("beginner")}
              className={difficulty === "beginner" ? "bg-blue-100 text-primary border-2 border-primary" : ""}
            >
              Beginner
            </Button>
            <Button
              variant={difficulty === "intermediate" ? "default" : "outline"}
              onClick={() => handleDifficultyChange("intermediate")}
              className={difficulty === "intermediate" ? "bg-blue-100 text-primary border-2 border-primary" : ""}
            >
              Intermediate
            </Button>
            <Button
              variant={difficulty === "advanced" ? "default" : "outline"}
              onClick={() => handleDifficultyChange("advanced")}
              className={difficulty === "advanced" ? "bg-blue-100 text-primary border-2 border-primary" : ""}
            >
              Advanced
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Test Container */}
      <Card>
        <CardContent className="py-6">
          {/* Test Stats */}
          <div className="flex flex-wrap gap-4 mb-4">
            <div className="bg-gray-100 rounded-lg px-4 py-2">
              <span className="text-xs text-gray-500 block">Time</span>
              <span className="text-lg font-mono font-medium">{formatTime(elapsedTime)}</span>
            </div>
            <div className="bg-gray-100 rounded-lg px-4 py-2">
              <span className="text-xs text-gray-500 block">WPM</span>
              <span className="text-lg font-mono font-medium">{Math.round(wpm)}</span>
            </div>
            <div className="bg-gray-100 rounded-lg px-4 py-2">
              <span className="text-xs text-gray-500 block">Accuracy</span>
              <span className="text-lg font-mono font-medium">{Math.round(accuracy)}%</span>
            </div>
            <div className="bg-gray-100 rounded-lg px-4 py-2">
              <span className="text-xs text-gray-500 block">Progress</span>
              <span className="text-lg font-mono font-medium">{Math.round(progress)}%</span>
            </div>
          </div>

          {/* Test Progress Bar */}
          <div className="w-full h-2 bg-gray-200 rounded-full mb-6">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-300 ease-out" 
              style={{ width: `${progress}%` }}
            ></div>
          </div>

          {/* Test Content */}
          <div className="font-mono text-lg mb-6 leading-loose whitespace-pre-wrap">
            {status === "countdown" ? (
              <div className="flex items-center justify-center h-24">
                <span className="text-4xl font-bold text-primary">{countdown}</span>
              </div>
            ) : (
              renderTextWithHighlighting()
            )}
          </div>

          {/* Test Input */}
          <div className="relative">
            <textarea
              ref={textareaRef}
              id="typing-input"
              className={`w-full p-4 border border-gray-300 rounded-lg font-mono focus:outline-none focus:ring-2 focus:ring-primary ${
                status === "countdown" ? "opacity-50" : ""
              }`}
              rows={4}
              placeholder={
                status === "idle"
                  ? "Start the test when ready..."
                  : status === "countdown"
                  ? "Get ready to type..."
                  : "Type the text above here..."
              }
              value={typedText}
              onChange={handleTyping}
              disabled={status === "countdown" || status === "finished" || isLoading}
              autoComplete="off"
              autoCorrect="off"
              spellCheck="false"
            ></textarea>
            
            {/* Test Controls */}
            <div className="absolute top-4 right-4 flex gap-2">
              {status === "idle" && (
                <Button
                  onClick={startTest}
                  disabled={isLoading || !selectedText}
                  className="bg-primary text-white"
                >
                  {isLoading ? "Loading..." : "Start Test"}
                </Button>
              )}
              
              {(status === "running" || status === "finished") && (
                <Button
                  onClick={resetTest}
                  variant="outline"
                  className="bg-gray-200 text-gray-700 hover:bg-gray-300"
                >
                  Reset
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}