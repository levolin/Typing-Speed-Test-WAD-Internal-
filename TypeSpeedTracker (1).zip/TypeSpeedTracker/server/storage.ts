import { 
  User, InsertUser, users, 
  TypingTest, InsertTypingTest, typingTests, 
  TextSample, InsertTextSample, textSamples,
  TestDifficultyType
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Typing test operations
  saveTypingTest(test: InsertTypingTest): Promise<TypingTest>;
  getUserTests(userId: number): Promise<TypingTest[]>;
  getRecentUserTests(userId: number, limit: number): Promise<TypingTest[]>;
  
  // Text sample operations
  getAllTextSamples(): Promise<TextSample[]>;
  getTextSamplesByDifficulty(difficulty: TestDifficultyType): Promise<TextSample[]>;
  createTextSample(sample: InsertTextSample): Promise<TextSample>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private typingTests: Map<number, TypingTest>;
  private textSamples: Map<number, TextSample>;
  private userId: number;
  private testId: number;
  private sampleId: number;

  constructor() {
    this.users = new Map();
    this.typingTests = new Map();
    this.textSamples = new Map();
    this.userId = 1;
    this.testId = 1;
    this.sampleId = 1;
    
    // Seed some default text samples
    this.seedTextSamples();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Typing test operations
  async saveTypingTest(test: InsertTypingTest): Promise<TypingTest> {
    const id = this.testId++;
    const completedAt = new Date();
    const typingTest: TypingTest = { ...test, id, completedAt };
    this.typingTests.set(id, typingTest);
    return typingTest;
  }

  async getUserTests(userId: number): Promise<TypingTest[]> {
    return Array.from(this.typingTests.values())
      .filter(test => test.userId === userId)
      .sort((a, b) => b.completedAt.getTime() - a.completedAt.getTime());
  }

  async getRecentUserTests(userId: number, limit: number): Promise<TypingTest[]> {
    return (await this.getUserTests(userId)).slice(0, limit);
  }

  // Text sample operations
  async getAllTextSamples(): Promise<TextSample[]> {
    return Array.from(this.textSamples.values());
  }

  async getTextSamplesByDifficulty(difficulty: TestDifficultyType): Promise<TextSample[]> {
    return Array.from(this.textSamples.values())
      .filter(sample => sample.difficulty === difficulty);
  }

  async createTextSample(sample: InsertTextSample): Promise<TextSample> {
    const id = this.sampleId++;
    const textSample: TextSample = { ...sample, id };
    this.textSamples.set(id, textSample);
    return textSample;
  }

  // Seed some default text samples
  private seedTextSamples() {
    const samples: InsertTextSample[] = [
      {
        title: "The Quick Brown Fox",
        difficulty: "beginner",
        text: "The quick brown fox jumps over the lazy dog. This paragraph is designed to use every letter of the alphabet at least once. It's a great way to practice typing speed and accuracy for beginners."
      },
      {
        title: "Typing Practice",
        difficulty: "beginner",
        text: "Learning to type quickly and accurately is an essential skill in today's digital world. Regular practice can help improve your typing speed and reduce errors. Start with short sessions and gradually increase your practice time."
      },
      {
        title: "Introduction to Computers",
        difficulty: "intermediate",
        text: "Computers have revolutionized the way we live and work. From performing complex calculations to facilitating global communication, these electronic devices have become an integral part of modern society. Understanding how to efficiently use computers is becoming increasingly important in nearly every profession."
      },
      {
        title: "The Internet",
        difficulty: "intermediate",
        text: "The Internet is a global network of interconnected computers that communicate using standardized protocols. It has transformed how we access information, communicate with others, and conduct business. Despite its relatively recent mainstream adoption, it's difficult to imagine modern life without the Internet's ubiquitous presence."
      },
      {
        title: "Artificial Intelligence",
        difficulty: "advanced",
        text: "Artificial Intelligence represents the culmination of decades of research in computer science, psychology, and philosophy. Modern AI systems utilize sophisticated algorithms and vast quantities of data to recognize patterns, make predictions, and solve complex problems. The field continues to evolve rapidly, with applications ranging from natural language processing to autonomous vehicles and advanced medical diagnostics."
      },
      {
        title: "Quantum Computing",
        difficulty: "advanced",
        text: "Quantum computing leverages the principles of quantum mechanics to process information in fundamentally different ways than classical computers. While traditional computers use bits that exist in binary states (0 or 1), quantum computers utilize quantum bits or qubits that can exist in multiple states simultaneously through a phenomenon called superposition. This potentially allows quantum computers to solve certain complex problems exponentially faster than their classical counterparts."
      }
    ];

    samples.forEach(sample => {
      const id = this.sampleId++;
      const textSample: TextSample = { ...sample, id };
      this.textSamples.set(id, textSample);
    });
  }
}

export const storage = new MemStorage();
