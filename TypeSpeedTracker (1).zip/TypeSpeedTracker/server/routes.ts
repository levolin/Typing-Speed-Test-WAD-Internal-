import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTypingTestSchema, TestDifficulty, TestDifficultyType } from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes prefix
  const apiRouter = '/api';

  // Get all text samples
  app.get(`${apiRouter}/samples`, async (req, res) => {
    try {
      const samples = await storage.getAllTextSamples();
      res.json(samples);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch text samples" });
    }
  });

  // Get text samples by difficulty
  app.get(`${apiRouter}/samples/:difficulty`, async (req, res) => {
    try {
      const difficulty = req.params.difficulty as TestDifficultyType;
      
      // Validate difficulty
      if (!Object.values(TestDifficulty).includes(difficulty)) {
        return res.status(400).json({ message: "Invalid difficulty level" });
      }
      
      const samples = await storage.getTextSamplesByDifficulty(difficulty);
      res.json(samples);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch text samples" });
    }
  });

  // Save typing test result
  app.post(`${apiRouter}/tests`, async (req, res) => {
    try {
      console.log("Received test data:", req.body);
      
      // Create a custom validation schema for the test data
      const customTestSchema = z.object({
        userId: z.number(),
        difficulty: z.enum(["beginner", "intermediate", "advanced"]),
        wpm: z.number(),
        accuracy: z.number(),
        keystrokes: z.number(),
        errors: z.number(),
        duration: z.number(),
        textSampleId: z.string() // Accept string ID for text samples
      });
      
      // Parse and validate the incoming data
      const parsedData = customTestSchema.parse(req.body);
      console.log("Parsed test data:", parsedData);
      
      const savedTest = await storage.saveTypingTest(parsedData);
      res.status(201).json(savedTest);
    } catch (error) {
      console.error("Error saving test:", error);
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to save test result" });
    }
  });

  // Get user's typing test history
  app.get(`${apiRouter}/users/:userId/tests`, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const tests = await storage.getUserTests(userId);
      res.json(tests);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch test history" });
    }
  });

  // Get recent test results for a user
  app.get(`${apiRouter}/users/:userId/tests/recent`, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      const tests = await storage.getRecentUserTests(userId, limit);
      res.json(tests);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recent tests" });
    }
  });

  // Create a demo user if none exists
  app.get(`${apiRouter}/demo-user`, async (req, res) => {
    try {
      // Check if a demo user already exists
      let user = await storage.getUserByUsername("demo");
      
      // If not, create one
      if (!user) {
        user = await storage.createUser({
          username: "demo",
          password: "demo123" // In a real app, this would be hashed
        });
      }
      
      res.json({ userId: user.id, username: user.username });
    } catch (error) {
      res.status(500).json({ message: "Failed to create demo user" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
